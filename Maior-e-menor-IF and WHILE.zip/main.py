valor1 = 1
while valor1 >= 0:
  valor1 = float (input("Digite o primeiro valor: "))
  valor2 = float (input("Digite o segundo valor: "))
  valor3 = float (input("Digite o terceiro valor: "))
  
  igual = valor1
  if valor2 == igual:
    if valor3 == igual:
      print("Programa encerrado: Valores iguais")
      quit()
  
  maior = valor1
  if valor2 > maior:
    maior = valor2
    if valor3 > maior:
      maior = valor3
  print ("O maior valor é o: ", maior)
  
  menor = valor1
  if valor2 < menor:
    menor = valor2
    if valor3 < menor:
      menor = valor3
  print ("O menor valor é o :", menor)


      