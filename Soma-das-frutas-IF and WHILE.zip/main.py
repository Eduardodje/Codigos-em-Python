# Valores das frutas.
macakg = 2.30
melanciaun = 4
laranjaun = 0.30

# Entrada de dados.
maca = int (input("Digite a quantidade de maça em KG: "))
melancia = int (input("Digite a quantidade de melancias: "))
laranja = int (input("Digite a quantidade de laranjas: "))

# Condição se todos as quantidades das frutas forem 0, encerrar programa.
if maca == 0:
  if melancia == 0:
    if laranja == 0:
      print ("Todos os valores foram nulos")
      quit()

# Cálculo das quantidades de frutas vezes o valor unitário.
somakg = maca * macakg
somamelanun = melancia * melanciaun
somalaranun = laranja * laranjaun

# Soma dos valores totais obtidos de cada fruta.
somatotal = somakg + somamelanun + somalaranun

# Mostra o valor final somado de todas as frutas.
print ("O valor total a pagar é: R$", somatotal)


# Versão opcinal ------------------------------------

# qtdmaca = 1
# qtdlaranja = 0
# qtdmelancia = 0
# while qtdmaca > 0 or qtdlaranja > 0 or qtdmelancia > 0:
#   qtdmaca = int (input("Digite a quantidade de maça em KG: "))
#   qtdmelancia = int (input("Digite a quantidade de melancias: "))
#   qtdlaranja = int (input("Digite a quantidade de laranjas: "))
#   valorpagar = qtdmaca * 2.30 + qtdlaranja * 0.30 + qtdmelancia * 4
#   print ("Valor total a pagar: R$", valorpagar)


